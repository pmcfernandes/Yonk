# smtp-configuration plugin

Plugin for wordpress to manage and configure email authentication to send emails with servers need username and password.

